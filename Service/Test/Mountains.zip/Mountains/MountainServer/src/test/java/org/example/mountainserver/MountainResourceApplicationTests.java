package org.example.mountainserver;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MountainResourceApplicationTests {

    @Test
    void contextLoads() {
    }

}
